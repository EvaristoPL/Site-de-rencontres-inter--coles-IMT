<?php
echo '
<select name="menu">
    <option value="menu1">Profil</option>
    <option value="menu2">Deconnexion</option>
</select>';
echo $_POST['menu'];
?>
